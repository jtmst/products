const config = {}

config.MONGO_URL = "mongodb://ubuntu@ec2-35-172-229-132.compute-1.amazonaws.com:27017/products?authSource=admin"


module.exports = config