const config = {}

config.MONGO_URL = "mongodb://ubuntu:kfg7528@ec2-54-197-3-230.compute-1.amazonaws.com:27017/products?authSource=admin"

module.exports = config